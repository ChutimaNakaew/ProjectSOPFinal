package com.example.tourservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TourServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
